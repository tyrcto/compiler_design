void         RangeCheck(int, int, int, char *);
char        *ArbName(void);
char        *ConsStrings(char *, char *);
void	     ReportID(char *);
/* void         bzero(unsigned char*, int); */
char        *TermString(int);
